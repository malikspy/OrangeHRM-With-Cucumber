package step_definitions;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SearchUser{
    public WebDriver driver;
    
    public SearchUser()
    {
    	driver = Hooks.driver;
    }
    //Add job title
    @Given("I login OrangeHRM")
    public void I_login_OrangeHRM() throws Throwable {
        driver.get("http://qa.cilsy.id");
        driver.manage().window().maximize();
        By inputUsername = By.id("txtUsername");
		By inputPassword = By.id("txtPassword");
		By btnLogin = By.id("btnLogin");
		driver.findElement(inputUsername).sendKeys("Admin");
		driver.findElement(inputPassword).sendKeys("s3Kol4HQA!*");
		driver.findElement(btnLogin).click();
    }
    @When("I navigated to User Management menus")
    public void nav_user() throws Throwable {
    	driver.findElement(By.id("menu_admin_viewAdminModule")).click();
		driver.findElement(By.id("menu_admin_UserManagement")).click();
		driver.findElement(By.xpath("//*[@id=\"systemUser-information\"]/div[1]/h1")).getText();

		driver.findElement(By.id("searchSystemUser_userName")).sendKeys("Malik");
		By btnDropdown1 = By.id("searchSystemUser_userType");
		Select dropdown1 = new Select(driver.findElement(By.id("searchSystemUser_userType")));
		dropdown1.selectByValue("2");
		driver.findElement(By.id("searchSystemUser_employeeName_empName")).sendKeys("Malik QA Mukti");
    }
    @And("^I Search USername userRole Employee Name and Status$")
    public void inputku() throws Throwable {
    	driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.findElement(By.id("searchBtn")).click();
    }
    @Then("^I enter search and I get User$")
    public void i_get_User() throws Throwable {
    	driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[contains(text(),'Malik')]")).getText();
		System.out.println("Searching success");
    }
    }