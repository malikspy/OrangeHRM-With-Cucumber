package step_definitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.LoginPage;
import pageObject.allPage;

public class AdminStep {
	 public static WebDriver driver;
	 
	public AdminStep()
    {
    	driver = Hooks.driver;
    }
	@Given("1homepage with authorization using \"(.*)\" as username & \"(.*)\" as password")
	public void VisitLoginPage2(String username, String password) throws Throwable {
		LoginPage loginPage = new LoginPage(driver);
		Assert.assertTrue(loginPage.isLoginPageAppear());
		loginPage.setUsername(username);
		loginPage.setPassword(password);
		loginPage.clickLoginButton();
		Thread.sleep(3000);
	}
	
	@When("2User click Admin button and click add button")
	public void goToAdminPageToAddUser() throws Throwable {
		allPage AllPage = new allPage (driver);
		AllPage.adminBtn();
		Thread.sleep(3000);
		AllPage.addUserBtn();
		Thread.sleep(5000);
				
	
		
	}
	
	@When("User select Admin as role & input \"(.*)\" as employeeUserName & input \"(.*)\" as userName & input \"(.*)\" as userPassword & input \"(.*)\" as userRePass & click save button")
	public void inputCredentialToAddUser(String employeeUserName, String userName, String userPassword, String userRePass) throws Throwable {
		allPage AllPage = new allPage (driver);
		AllPage.addUserEmployeeName(employeeUserName);
		Thread.sleep(5000);
		AllPage.User_Name(userName);
		Thread.sleep(5000);
		AllPage.UserPassword(userPassword); 
		AllPage.userConfPassword(userRePass);
		AllPage.saveUserBtn();
		Thread.sleep(5000);
	
	}
	
	@Then("User succesfully add new user data")
	public void userSuccessfullAddNewUser() throws Throwable {
		allPage AllPage = new allPage (driver);
		
	
	}
}
