package step_definitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.LoginPage;
import pageObject.allPage;

public class leaveStep {

	public static WebDriver driver;

	public leaveStep() {
		driver = Hooks.driver;
	}

	// Negative
	@Given("16User on homepage with authorization using \"(.*)\" as username & \"(.*)\" as password")
	public void VisitLoginPage4(String username, String password) throws Throwable {
		LoginPage loginPage = new LoginPage(driver);
		Assert.assertTrue(loginPage.isLoginPageAppear());
		loginPage.setUsername(username);
		loginPage.setPassword(password);
		loginPage.clickLoginButton();
		Thread.sleep(3000);
	}

	@When("1User click leave button & assign leave button")
	public void goToAssignLeave1() throws Throwable {
		allPage AllPage = new allPage(driver);
		AllPage.leaveBtn();
		Thread.sleep(3000);
		AllPage.leaveAssignBtn();

	}

	@When("User input \"(.*)\" as xEmployeeNameToLeave & select leave type & input \"(.*)\" as leaveFromDate & select partialDays & input \"(.*)\" as leaveToDate & input \"(.*)\" as commentLeave & click assign button")
	public void inputFailedAssign(String xEmployeeNameToLeave, String leaveFromDate, String leaveToDate,
			String commentLeave) throws Throwable {
		allPage AllPage = new allPage(driver);
		AllPage.xleaveAssignName(xEmployeeNameToLeave);
		AllPage.leaveType();
		AllPage.leaveAssignFromDate(leaveFromDate);
		AllPage.leaveAssignToDate(leaveToDate);
		AllPage.textCommentLeave(commentLeave);
		AllPage.assignBtn();

		Thread.sleep(3000);
	}

	@Then("User cant assign leave and get error Message bellow employee name")
	public void UnsuccessfulAssignLeave() throws Throwable {
		allPage AllPage = new allPage(driver);
		Assert.assertEquals(AllPage.assignErrorExp(), AllPage.assignErrorAct());

	}

	// Positif
	@Given("17User on homepage with authorization using \"(.*)\" as username & \"(.*)\" as password")
	public void VisitLoginPage5(String username, String password) throws Throwable {
		LoginPage loginPage = new LoginPage(driver);
		Assert.assertTrue(loginPage.isLoginPageAppear());
		loginPage.setUsername(username);
		loginPage.setPassword(password);
		loginPage.clickLoginButton();
		Thread.sleep(3000);
	}

	@When("2User click leave button & assign leave button")
	public void goToAssignLeave2() throws Throwable {
		allPage AllPage = new allPage(driver);
		AllPage.leaveBtn();
		Thread.sleep(3000);
		AllPage.leaveAssignBtn();
		Thread.sleep(5000);

	}

	@When("User input \"(.*)\" as employeeNameToLeave & select leave type & input \"(.*)\" as leaveFromDate & input \"(.*)\" as leaveToDate & select partial days")
	public void inputAssignLeave(String employeeNameToLeave, String leaveFromDate, String leaveToDate) throws Throwable {
		allPage AllPage = new allPage(driver);
		AllPage.tleaveAssignName(employeeNameToLeave);
		AllPage.leaveType();
		Thread.sleep(5000);
		AllPage.leaveAssignFromDate(leaveFromDate);
		Thread.sleep(5000);
		AllPage.leaveAssignToDate(leaveToDate);
		Thread.sleep(5000);

	}

	@When("User User select duration days & select time from & select time to & input \"(.*)\" as commentLeave & click assign button")
	public void InputAssignLeaveSpecified(String commentLeave) throws Throwable {
		allPage AllPage = new allPage(driver);
		AllPage.textCommentLeave(commentLeave);
		Thread.sleep(5000);
		AllPage.assignBtn();
				
	}

	@Then("User successfully assign leave")
	public void successfulAssignLeave() throws Throwable {

	}
	
	
//Search	
	@Given("18User on homepage with authorization using \"(.*)\" as username & \"(.*)\" as password")
	public void VisitLoginPage6(String username, String password) throws Throwable {
		LoginPage loginPage = new LoginPage(driver);
		Assert.assertTrue(loginPage.isLoginPageAppear());
		loginPage.setUsername(username);
		loginPage.setPassword(password);
		loginPage.clickLoginButton();
		Thread.sleep(3000);
	}

	@When("3User click leave button")
	public void goToLeaveList() throws Throwable {
		allPage AllPage = new allPage(driver);
		AllPage.leaveBtn();
		Thread.sleep(3000);
		
	}

	@When("User click chek all status leave & input \"(.*)\" as fullNameLeave & click search button")
	public void inputCredentialToFindDataLeave(String fullNameLeave) throws Throwable {
		allPage AllPage = new allPage(driver);
		AllPage.allCheckBtn();
		AllPage.searchNameLeave(fullNameLeave);
		AllPage.searchLeaveBtn();

		Thread.sleep(3000);
	}

	@Then("User get the result on leave list")
	public void getSuitableResultLeave() throws Throwable {
		allPage AllPage = new allPage(driver);
		Assert.assertEquals(AllPage.actResultLeaveName(), AllPage.expResultLeaveName());
		Assert.assertEquals(AllPage.actStatusLeave(), AllPage.expStatusLeave());

	}
	
}
