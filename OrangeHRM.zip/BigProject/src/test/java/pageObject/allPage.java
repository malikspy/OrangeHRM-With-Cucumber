package pageObject;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import gherkin.lexer.Id;
import utilities.BaseClass;

public class allPage extends BaseClass {

	public allPage(WebDriver webDriver) {
		super(webDriver);
		PageFactory.initElements(webDriver, this);

	}

//pim	
	@FindBy(xpath = "//b[.='PIM']")
	private WebElement PIMBtn;

	public void PIMBtn() {
		PIMBtn.click();
	}

	@FindBy(xpath = "//a[@id='menu_pim_addEmployee']")
	private WebElement addEmployeeBtn;

	public void addEmployeeBtn() {
		addEmployeeBtn.click();
	}

	@FindBy(id = "firstName")
	private WebElement firstNameEmployee;

	public void firstNameEmployee(String firstName) {
		firstNameEmployee.sendKeys(firstName);
	}

	@FindBy(id = "middleName")
	private WebElement middleNameEmployee;

	public void middleNameEmployee(String middleName) {
		middleNameEmployee.sendKeys(middleName);
	}

	@FindBy(id = "lastName")
	private WebElement lastNameEmployee;

	public void lastNameEmployee(String lastName) {
		lastNameEmployee.sendKeys(lastName);
	}

	@FindBy(id = "employeeId")
	private WebElement idEmployee;

	public void idEmployee(String id_Employee) {
		idEmployee.clear();
		idEmployee.sendKeys(id_Employee);
	}

	@FindBy(id = "chkLogin")
	private WebElement chckBoxEmployee;

	public void chckBoxEmployee() {
		chckBoxEmployee.click();
	}

	@FindBy(id = "btnSave")
	private WebElement save1Btn;

	public void save1Btn() {
		save1Btn.click();
	}

	@FindBy(id = "user_name")
	private WebElement unameEmployee;

	public void unameEmployee(String unameEmploy) {
		unameEmployee.sendKeys(unameEmploy);
	}

	@FindBy(id = "user_password")
	private WebElement passEmployee;

	public void passEmployee(String passEmploy) {
		passEmployee.sendKeys(passEmploy);
	}

	@FindBy(id = "re_password")
	private WebElement rePassEmployee;

	public void rePassEmployee(String rePassEmploy) {
		rePassEmployee.sendKeys(rePassEmploy);
	}

	@FindBy(id = "btnSave")
	private WebElement editBtn;

	public void editBtn() {
		editBtn.click();
	}

	@FindBy(id = "btnSave")
	private WebElement save2Btn;

	public void save2Btn() {
		save2Btn.click();
	}

	@FindBy(id = "personal_txtLicenNo")
	private WebElement SIMNumber;

	public void SIMNumber(String SIMNumb) {
		SIMNumber.sendKeys(SIMNumb);
	}

	@FindBy(id = "personal_optGender_2")
	private WebElement genderChckBox;

	public void genderChckBox() {
		genderChckBox.click();
	}

	public void nationality() {
		Select nationality = new Select(webDriver.findElement(By.id("personal_cmbNation")));
		nationality.selectByVisibleText("Indonesian");
	}

	@FindBy(id = "personal_txtOtherID")
	private WebElement otherId;

	public void otherId(String otherID) {
		otherId.sendKeys(otherID);
	}

	@FindBy(id = "personal_txtLicExpDate")
	private WebElement licExpDate;

	public void licExpDate(String SIMExpDate) {
		licExpDate.sendKeys(SIMExpDate);
	}

	public void maritalStatus() {
		Select maritalStatus = new Select(webDriver.findElement(By.id("personal_cmbMarital")));
		maritalStatus.selectByValue("Single");

	}

	@FindBy(id = "personal_DOB")
	private WebElement birthDate;

	public void birthDate(String BirthDate) {
		birthDate.sendKeys(BirthDate);
	}

	@FindBy(id = "menu_pim_viewEmployeeList")
	private WebElement employeeListBtn;

	public void employeeListBtn() {
		employeeListBtn.click();
	}

	@FindBy(id = "empsearch_employee_name_empName")
	private WebElement fullNameToSearch;

	public void searchName(String fullName) {
		fullNameToSearch.sendKeys(fullName);
	}

	@FindBy(id = "empsearch_id")
	private WebElement idToSearch;

	public void idToSearch(String idEmployee) {
		idToSearch.sendKeys(idEmployee);
	}

	@FindBy(id = "searchBtn")
	private WebElement searchBtn;

	public void searchBtn() {
		searchBtn.click();
	}

	@FindBy(xpath = "//td[.='rere rere']")
	private WebElement resultName;

	@FindBy(css = "tbody td:nth-of-type(2) > [href='/symfony/web/index.php/pim/viewEmployee/empNumber/26']")
	private WebElement resultID;

	public String getResultNameAct() {
		return resultName.getText();
	}

	public String getResultNameExp() {
		return "rere rere";
	}

	public String getResultIDAct() {
		return resultID.getText();
	}

	public String getResultIDExp() {
		return "009";
	}

//admin
	@FindBy(xpath = "//b[.='Admin']")
	private WebElement adminBtn;

	public void adminBtn() {
		adminBtn.click();
	}

	@FindBy(id = "btnAdd")
	private WebElement addUserBtn;

	public void addUserBtn() {
		addUserBtn.click();
	}

	public void userType() {
		Select userType = new Select(webDriver.findElement(By.id("systemUser_userType")));
		userType.selectByValue("2");

	}
	
	@FindBy(id = "systemUser_employeeName_empName")
	private WebElement addUserEmployeeName;

	public void addUserEmployeeName(String employeeUserName) {
		addUserEmployeeName.clear();
		addUserEmployeeName.sendKeys(employeeUserName);
	}
	
	@FindBy(id = "systemUser_userName")
	private WebElement User_Name;

	public void User_Name(String UserName) {
		User_Name.clear();
		User_Name.sendKeys(UserName);
	}
	
	@FindBy(xpath = "//input[@id='systemUser_password']")
	private WebElement UserPassword;

	public void UserPassword(String userPassword) {
		UserPassword.sendKeys(userPassword);
	}
	
	@FindBy(id = "systemUser_confirmPassword")
	private WebElement userConfPassword;

	public void userConfPassword(String userRePass) {
		userConfPassword.sendKeys(userRePass);
	}
	
	@FindBy(id = "btnSave")
	private WebElement saveUserBtn;

	public void saveUserBtn() {
		new WebDriverWait(webDriver, 20)
		.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='btnSave']"))).click();;
	
	}
	
	@FindBy(id = "searchSystemUser_userName")
	private WebElement searchUserName;

	public void searchUserName(String userName) {
		searchUserName.sendKeys(userName);
	}
	
	@FindBy(id = "searchBtn")
	private WebElement searchUserNameBtn;

	public void searchUserNameBtn() {
		searchUserName.click();
	}
	
	@FindBy(css = "td:nth-of-type(2) > a")
	private WebElement resultUserName;
	
	public String actUserName() {
		return resultUserName.getText();
	}
	
	public String expUserName() {
		return "TinyWiniBity";
	}
	

//leave
	@FindBy(xpath = "//b[.='Leave']")
	private WebElement leaveBtn;

	public void leaveBtn() {
		leaveBtn.click();
	}

	@FindBy(id = "menu_leave_assignLeave")
	private WebElement leaveAssignBtn;

	public void leaveAssignBtn() {
		leaveAssignBtn.click();
	}

	@FindBy(id = "assignleave_txtEmployee_empName")
	private WebElement xLeaveAssignName;

	public void xleaveAssignName(String xEmployeeNameToLeave) {
		xLeaveAssignName.clear();
		xLeaveAssignName.sendKeys(xEmployeeNameToLeave);
	}

	@FindBy(xpath = "//input[@id='assignleave_txtEmployee_empName']")
	private WebElement leaveAssignName;

	public void tleaveAssignName(String employeeNameToLeave) {
		leaveAssignName.clear();
		leaveAssignName.sendKeys(employeeNameToLeave);
	}

	public void leaveType() {
		Select leaveType = new Select(webDriver.findElement(By.id("assignleave_txtLeaveType")));
		leaveType.selectByVisibleText("Emergency Leave");

	}

	@FindBy(id = "assignleave_txtFromDate")
	private WebElement leaveAssignFromDate;

	public void leaveAssignFromDate(String leaveFromDate) {
		leaveAssignFromDate.clear();
		leaveAssignFromDate.sendKeys(leaveFromDate);
		leaveAssignFromDate.sendKeys(Keys.ENTER);
	}

	@FindBy(id = "assignleave_txtToDate")
	private WebElement leaveAssignToDate;

	public void leaveAssignToDate(String leaveToDate) {
		leaveAssignToDate.clear();
		leaveAssignToDate.sendKeys(leaveToDate);
		leaveAssignToDate.sendKeys(Keys.ENTER);
	}

	public void partialDays() {
		Select leaveType = new Select(webDriver.findElement(By.id("assignleave_partialDays")));
		leaveType.selectByValue("all");

	}

	public void durationDays() {
		new WebDriverWait(webDriver, 20)
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@id='frmLeaveApply']//li[8]")));
		new WebDriverWait(webDriver, 20).until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//select[@id='assignleave_firstDuration_duration']")));
		Select durationDays = new Select(webDriver.findElement(By.id("assignleave_duration_duration")));
		durationDays.selectByVisibleText("Specify Time");

	}

	public void durationTimeFrom() {
		Select durationTimeFrom = new Select(webDriver.findElement(By.id("assignleave_firstDuration_time_from")));
		durationTimeFrom.selectByVisibleText("08:00");

	}

	public void durationTimeTo() {
		Select durationTimeTo = new Select(webDriver.findElement(By.id("assignleave_firstDuration_time_to")));
		durationTimeTo.selectByVisibleText("16:00");

	}

	@FindBy(id = "assignleave_txtComment")
	private WebElement textCommentLeave;

	public void textCommentLeave(String commentLeave) {
		new WebDriverWait(webDriver, 20).until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@id='assignleave_txtComment']")));
		textCommentLeave.sendKeys(commentLeave);
	}

	@FindBy(id = "assignBtn")
	private WebElement assignBtn;

	@FindBy(id = "confirmOkButton")
	private WebElement OkBtn;

	public void assignBtn() {
		assignBtn.click();

		if (OkBtn.isDisplayed()) {
			OkBtn.click();
		}

	}

	@FindBy(css = "[for='assignleave_txtEmployee_empName']")
	private WebElement isAssignErrorAppear;

	public String assignErrorExp() {
		return "Invalid";
	}

	public String assignErrorAct() {
		return isAssignErrorAppear.getText();
	}

	@FindBy(id = "leaveList_chkSearchFilter_checkboxgroup_allcheck")
	private WebElement allCheckBtn;

	public void allCheckBtn() {
		allCheckBtn.click();
	}

	@FindBy(id = "leaveList_txtEmployee_empName")
	private WebElement searchNameLeave;

	public void searchNameLeave(String fullNameLeave) {
		searchNameLeave.clear();
		searchNameLeave.sendKeys(fullNameLeave);

	}

	@FindBy(id = "btnSearch")
	private WebElement searchLeaveBtn;

	public void searchLeaveBtn() {
		searchLeaveBtn.click();
	}

	@FindBy(xpath = "//tr[@class='odd']//a[.='rere rere caesaria']")
	private WebElement isResultLeaveName;

	public String expResultLeaveName() {
		return "rere rere caesaria";
	}

	public String actResultLeaveName() {
		return isResultLeaveName.getText();
	}

	@FindBy(xpath = "//a[.='Scheduled(1.00)']")
	private WebElement statusLeave;

	public String actStatusLeave() {
		return statusLeave.getText();

	}

	public String expStatusLeave() {
		return "Scheduled(1.00)";

	}

//Time	
	@FindBy(xpath = "//b[.='Time']")
	private WebElement timeBtn;

	@FindBy(xpath = "//b[.='Recruitment']")
	private WebElement recruitmentBtn;

	@FindBy(xpath = "//b[.='My Info']")
	private WebElement myInfoBtn;

	@FindBy(xpath = "//b[.='Performance']")
	private WebElement performanceBtn;

	@FindBy(xpath = "//b[.='Dashboard']")
	private WebElement dashboardBtn;

	@FindBy(xpath = "//b[.='Directory']")
	private WebElement directoryBtn;

	@FindBy(xpath = "//b[.='Maintenance']")
	private WebElement mtcBtn;

	@FindBy(xpath = "//b[.='Buzz']")
	private WebElement buzzBtn;

}
